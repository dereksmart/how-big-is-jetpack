<?php
/**
 * Deprecated since 7.5 – Jetpack_Options are autoloaded from packages/options/legacy/class.jetpack-options.php
 */
_deprecated_file( basename( __FILE__ ), 'jetpack-7.5' );
