<?php
/**
 * Deprecated file since 7.5 - Jetpack_Tracks_Client is now autoloaded from 'vendor/automattic/jetpack-tracking/legacy/class.tracks-client.php'
 */
_deprecated_file( basename( __FILE__ ), 'jetpack-7.5' );
