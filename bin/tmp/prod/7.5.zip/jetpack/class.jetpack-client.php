<?php
/**
 * Deprecated since 7.5
 */
_deprecated_file( basename( __FILE__ ), 'jetpack-7.5' );
